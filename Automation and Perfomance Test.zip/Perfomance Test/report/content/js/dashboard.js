/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 73.33333333333333, "KoPercent": 26.666666666666668};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.43, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Get - Single Users"], "isController": false}, {"data": [0.0, 500, 1500, "Post - Login Unsuccessful"], "isController": false}, {"data": [0.425, 500, 1500, "Post - Login Successful"], "isController": false}, {"data": [0.0, 500, 1500, "Get - Delayed Response"], "isController": false}, {"data": [0.405, 500, 1500, "Delete - Delete"], "isController": false}, {"data": [0.0, 500, 1500, "Post - Register Unsuccessful"], "isController": false}, {"data": [0.9675, 500, 1500, "Get - List Users"], "isController": false}, {"data": [0.9925, 500, 1500, "Get - Single Resource"], "isController": false}, {"data": [0.41, 500, 1500, "Put - Update"], "isController": false}, {"data": [0.43, 500, 1500, "Post - Register Successful"], "isController": false}, {"data": [0.0, 500, 1500, "Get - Single Users Not Found"], "isController": false}, {"data": [0.995, 500, 1500, "Get - List Resource"], "isController": false}, {"data": [0.0, 500, 1500, "Get - List Resource Not Found"], "isController": false}, {"data": [0.4025, 500, 1500, "Patch - Update"], "isController": false}, {"data": [0.4225, 500, 1500, "Post - Create"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3000, 800, 26.666666666666668, 1101.1100000000008, 41, 19131, 773.0, 3654.9, 4076.95, 7159.699999999993, 16.06202081637898, 17.307758106635756, 2.967709314901272], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get - Single Users", 200, 0, 0.0, 66.34, 42, 271, 63.0, 82.9, 91.84999999999997, 225.2400000000007, 1.160355300793103, 1.3397514428292945, 0.1756397183817685], "isController": false}, {"data": ["Post - Login Unsuccessful", 200, 200, 100.0, 1375.029999999999, 739, 9288, 1063.0, 3075.1000000000026, 3710.9, 8068.800000000011, 1.1762145885895423, 1.0101891426571863, 0.2285807647747255], "isController": false}, {"data": ["Post - Login Successful", 200, 0, 0.0, 1392.3, 733, 13178, 1066.5, 2632.4, 4598.499999999988, 8002.09000000001, 1.1744670855599273, 0.999329269187856, 0.26379631804568676], "isController": false}, {"data": ["Get - Delayed Response", 200, 0, 0.0, 4413.37, 3744, 19131, 4063.0, 5108.5, 7037.999999999989, 16845.550000000047, 1.1550478478570974, 2.075972911240348, 0.24251492899343358], "isController": false}, {"data": ["Delete - Delete", 200, 0, 0.0, 1322.3500000000004, 743, 8304, 1072.5, 2563.7000000000025, 3137.7, 7346.700000000024, 1.1654468323155098, 0.9115751815183442, 0.20144930597641136], "isController": false}, {"data": ["Post - Register Unsuccessful", 200, 200, 100.0, 1341.4349999999995, 745, 8422, 1070.0, 2249.6000000000004, 3651.4999999999995, 6833.220000000001, 1.1595748998417181, 0.9954678739773999, 0.22761186998846222], "isController": false}, {"data": ["Get - List Users", 200, 0, 0.0, 410.84500000000025, 156, 7234, 190.0, 243.8, 377.6499999999997, 7223.99, 1.1584398132595022, 2.185961220865239, 0.1810062208217972], "isController": false}, {"data": ["Get - Single Resource", 200, 0, 0.0, 102.05500000000002, 42, 6764, 63.0, 76.0, 84.89999999999998, 1095.4100000000087, 1.1683403141667106, 1.2935660868047645, 0.17913030207438824], "isController": false}, {"data": ["Put - Update", 200, 0, 0.0, 1487.140000000001, 742, 10892, 1066.0, 3506.0000000000055, 4671.2, 9341.140000000012, 1.172353558386138, 1.0550495099562125, 0.2495830817657989], "isController": false}, {"data": ["Post - Register Successful", 200, 0, 0.0, 1315.0599999999993, 740, 8298, 1070.0, 2565.0000000000027, 3699.3499999999995, 7961.88000000001, 1.1674332811879802, 1.0021685073198066, 0.26107638807817135], "isController": false}, {"data": ["Get - Single Users Not Found", 200, 200, 100.0, 269.7699999999999, 41, 4707, 63.0, 1079.8, 1219.9, 3663.91, 1.1603620329542816, 1.0039567892057322, 0.17677390345787886], "isController": false}, {"data": ["Get - List Resource", 200, 0, 0.0, 74.57999999999994, 41, 1085, 63.5, 84.80000000000001, 95.89999999999998, 753.1500000000044, 1.168237946704985, 1.8361015552897813, 0.17683289232350843], "isController": false}, {"data": ["Get - List Resource Not Found", 200, 200, 100.0, 209.28499999999983, 42, 7031, 63.0, 289.10000000000105, 1088.8, 3621.550000000014, 1.1683198392391902, 1.0083604237496056, 0.18026810019510942], "isController": false}, {"data": ["Patch - Update", 200, 0, 0.0, 1391.71, 742, 10888, 1071.0, 2610.1, 3677.25, 7024.120000000002, 1.1612109107377173, 1.0454073382723503, 0.24947890660380645], "isController": false}, {"data": ["Post - Create", 200, 0, 0.0, 1345.3799999999999, 744, 11398, 1071.0, 2154.8, 3659.6, 7127.910000000002, 1.1703982865369085, 1.063056533528985, 0.23773715195280953], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 400, 50.0, 13.333333333333334], "isController": false}, {"data": ["404/Not Found", 400, 50.0, 13.333333333333334], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3000, 800, "400/Bad Request", 400, "404/Not Found", 400, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Post - Login Unsuccessful", 200, 200, "400/Bad Request", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Post - Register Unsuccessful", 200, 200, "400/Bad Request", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get - Single Users Not Found", 200, 200, "404/Not Found", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Get - List Resource Not Found", 200, 200, "404/Not Found", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
