<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Edit details_Svg-sc-ytk21e-0 kcUFwU</name>
   <tag></tag>
   <elementGuidId>2faf3530-c992-47fb-905a-c2432310fdfa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit details'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.MQQEonum615k8mGkliT_ > svg.Svg-sc-ytk21e-0.kcUFwU</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>05f1aaf1-9914-474f-bc8a-f7829d4273bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-encore-id</name>
      <type>Main</type>
      <value>icon</value>
      <webElementGuid>ae2b36d9-ac4e-47fe-99bf-06290cb07956</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>480fb477-5618-4cd6-8e3a-ad4ae90fda60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Close</value>
      <webElementGuid>1965f8f9-a6f1-4b0a-bdc7-abebfd8cadee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>3de80a77-70d4-4c01-99cb-0e34a9390060</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 16 16</value>
      <webElementGuid>66e190b1-f21d-4911-8a3d-4a59aa267c63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Svg-sc-ytk21e-0 kcUFwU</value>
      <webElementGuid>739e46a6-1e5b-4a12-9387-e89c1fadadbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-focus-outline spotify__os--is-windows spotify__container--is-web&quot;]/body[@class=&quot;encore-dark-theme encore-layout-themes GenericModal__Body--open&quot;]/div[@class=&quot;ReactModalPortal&quot;]/div[@class=&quot;GenericModal__overlay&quot;]/div[@class=&quot;GenericModal&quot;]/div[@class=&quot;PiyAiXdQULEnWAHP0tu1&quot;]/div[@class=&quot;R2w_sH83CJU9Yhnu0xyt&quot;]/button[@class=&quot;MQQEonum615k8mGkliT_&quot;]/svg[@class=&quot;Svg-sc-ytk21e-0 kcUFwU&quot;]</value>
      <webElementGuid>8daf853c-d7b4-47b7-9806-5b08852834ef</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit details'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>2415f895-0995-458f-8e0d-6f838fcb5be3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Now playing: Mesin Waktu by Budi Doremi'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>a5a764be-27f9-4c4c-8e47-f84665f23e40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Choose photo'])[2]/preceding::*[name()='svg'][3]</value>
      <webElementGuid>bc26c86c-f7e4-4ec7-967c-dc2f2347d066</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit photo'])[1]/preceding::*[name()='svg'][4]</value>
      <webElementGuid>fadcef1e-f7d8-4860-890b-52130094d729</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
