<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_PlaylistTesting Brins_Svg-sc-ytk21e-0 dYnaPI</name>
   <tag></tag>
   <elementGuidId>d75a3dd1-06b0-4c5f-bbe0-bcd1b6e6e1a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='My Playlist #190'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.Button-sc-1dqy6lx-0.hidZeW.yclq4HDmRA_euiUYwB9O > span.IconWrapper__Wrapper-sc-16usrgb-0.hYdsxw > svg.Svg-sc-ytk21e-0.dYnaPI</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>41d24f1b-e639-4942-91b1-fbcf0632eb89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-encore-id</name>
      <type>Main</type>
      <value>icon</value>
      <webElementGuid>ae6162fa-036c-4616-b5af-3cdb170a9a22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>21b42788-f763-4821-9ece-cea2106d193c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>84d1fb1c-acef-4b17-b6a2-f74fef15d26d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 16 16</value>
      <webElementGuid>253c26ff-540e-4c74-9ca3-1bc685e0e4e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Svg-sc-ytk21e-0 dYnaPI</value>
      <webElementGuid>5baeb896-70f9-4bbb-ad1d-e42773b6dc5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Desktop_LeftSidebar_Id&quot;)/nav[@class=&quot;lYpiKR_qEjl1jGGyEvsA&quot;]/div[@class=&quot;lHJd4oSttKLxkxuoZ0Lr wM72343CksOCaL3bZvKK&quot;]/div[@class=&quot;hgJel0bLlS_1Uf0EIfSA&quot;]/div[@class=&quot;cZ3IJprhLYLVtLoxVtDe&quot;]/div[@class=&quot;Popover__StyledPopover-sc-1iog353-0 hUICWc encore-announcement-set C8nlESBb6d0huyAhMq2v&quot;]/button[@class=&quot;Button-sc-1dqy6lx-0 hidZeW yclq4HDmRA_euiUYwB9O&quot;]/span[@class=&quot;IconWrapper__Wrapper-sc-16usrgb-0 hYdsxw&quot;]/svg[@class=&quot;Svg-sc-ytk21e-0 dYnaPI&quot;]</value>
      <webElementGuid>9796adb0-e4f4-4a01-850b-45305515b488</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Playlist #190'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>96557915-40ef-4bc7-92eb-9a515dca1978</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Resize main navigation'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>77ff38f4-4185-4aa9-b0cd-97382ff35085</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mesin Waktu'])[1]/preceding::*[name()='svg'][3]</value>
      <webElementGuid>03008e1c-2b50-456b-ba81-4dbbb312c919</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
