<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Log in</name>
   <tag></tag>
   <elementGuidId>e7c37268-666e-423d-ac97-4187aad58757</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main']/div/div[2]/div[3]/header/div[2]/div[3]/div/button[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.LKFFk88SIRC9QKKUWR5u > button.Button-sc-qlcn5g-0.bRejwy > span.ButtonInner-sc-14ud5tc-0.cnKUru.encore-inverted-light-set</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8f022c45-9e48-4710-a778-53f05267d7a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ButtonInner-sc-14ud5tc-0 cnKUru encore-inverted-light-set</value>
      <webElementGuid>4426b980-dd7f-45f7-8a2c-6c54ea87bb91</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Log in</value>
      <webElementGuid>8456807d-098d-419d-83b9-9d1a47e50b14</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/div[@class=&quot;Root&quot;]/div[@class=&quot;ZQftYELq0aOsg6tPbVbV&quot;]/div[@class=&quot;jEMA2gVoLgPQqAFrPhFw&quot;]/header[@class=&quot;facDIsOQo9q7kiWc4jSg coBkWVskipFo8KxLKief qxbaGYC8rgMLfyOuYRCM&quot;]/div[@class=&quot;hV9v6y_uYwdAsoiOHpzk contentSpacing&quot;]/div[@class=&quot;rwdnt1SmeRC_lhLVfIzg&quot;]/div[@class=&quot;LKFFk88SIRC9QKKUWR5u&quot;]/button[@class=&quot;Button-sc-qlcn5g-0 bRejwy&quot;]/span[@class=&quot;ButtonInner-sc-14ud5tc-0 cnKUru encore-inverted-light-set&quot;]</value>
      <webElementGuid>7269c149-011e-4680-96e9-4462c73f333e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main']/div/div[2]/div[3]/header/div[2]/div[3]/div/button[2]/span</value>
      <webElementGuid>819da487-2657-4098-a7f1-e63288a5dd59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/following::span[1]</value>
      <webElementGuid>76d69687-b04b-4d26-a4ff-99dfe0a0b6a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change volume'])[1]/following::span[1]</value>
      <webElementGuid>6f052425-2e2b-4e62-8840-aa225e818918</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Popular artists'])[1]/preceding::span[1]</value>
      <webElementGuid>3f4f7df8-b318-4852-9194-11e7966abb25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Show all'])[1]/preceding::span[1]</value>
      <webElementGuid>24978448-a4bf-4944-9a03-d213e60871f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Log in']/parent::*</value>
      <webElementGuid>aeb55f88-63c3-4ddb-9e04-30e2f3942cda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]/span</value>
      <webElementGuid>409739fb-8ae4-4731-aa1f-7ba4ad856402</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Log in' or . = 'Log in')]</value>
      <webElementGuid>f594d1b9-555c-47c9-b528-478b7bbbd610</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
