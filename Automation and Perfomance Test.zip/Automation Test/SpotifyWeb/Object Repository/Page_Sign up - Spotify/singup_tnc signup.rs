<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>singup_tnc signup</name>
   <tag></tag>
   <elementGuidId>17143165-e528-49c0-a1bb-9fde194567fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/main/main/section/div/form/div[2]/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.ButtonInner-sc-14ud5tc-0.dIiEaI.encore-bright-accent-set</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>070cfcd9-dd20-494f-8b0f-cb2f9b166232</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ButtonInner-sc-14ud5tc-0 dIiEaI encore-bright-accent-set</value>
      <webElementGuid>0c3f3582-5411-4be3-86eb-b2e2d41a7d4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign up</value>
      <webElementGuid>5a16c938-899a-4cd6-bb62-176f9545e53c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/main[1]/main[@class=&quot;sc-idXfnW eUkEzb&quot;]/section[@class=&quot;sc-dIfA-dP iuSohp&quot;]/div[@class=&quot;sc-hHTZFM dbOZXE&quot;]/form[@class=&quot;sc-dsHIyT bdA-dJm&quot;]/div[@class=&quot;sc-kImOnM fZerbw&quot;]/button[@class=&quot;Button-sc-qlcn5g-0 cUOgcY&quot;]/span[@class=&quot;ButtonInner-sc-14ud5tc-0 dIiEaI encore-bright-accent-set&quot;]</value>
      <webElementGuid>0738b833-a1ea-432d-8213-76895574fbf3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/main/main/section/div/form/div[2]/button/span</value>
      <webElementGuid>b1b4f596-3123-479a-ac77-654af743ccf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Spotify Privacy Policy'])[1]/following::span[1]</value>
      <webElementGuid>a4a3dfd4-234f-4570-a1f5-0e27fe751206</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Privacy Policy'])[1]/preceding::span[2]</value>
      <webElementGuid>c817272c-a678-4220-bfdd-76b3b762d18d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Terms of Service'])[1]/preceding::span[2]</value>
      <webElementGuid>449fdafe-b6c1-4a83-bd43-784f02947b9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign up']/parent::*</value>
      <webElementGuid>711767fd-fa8f-45f3-9d5d-94a861e918c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/button/span</value>
      <webElementGuid>9cdc8e18-8a5f-4ea1-a440-42821496a985</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign up' or . = 'Sign up')]</value>
      <webElementGuid>8c72ab65-f2ae-48ba-9cf8-3f9b9318c0ad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
