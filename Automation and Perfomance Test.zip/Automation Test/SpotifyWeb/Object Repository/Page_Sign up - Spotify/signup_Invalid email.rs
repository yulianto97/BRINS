<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>signup_Invalid email</name>
   <tag></tag>
   <elementGuidId>60711c3e-60c8-4b31-a9de-5d5d61f4c6e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='username-error-message']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.Text-sc-g5kv67-0.iDJBsn</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ecfdd702-ff6c-479e-9470-23335b717975</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Text-sc-g5kv67-0 iDJBsn</value>
      <webElementGuid>cec957c9-cd54-49e8-bb54-e4605e84d3a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Invalid email address. Verify the spelling and try again.</value>
      <webElementGuid>783c43e7-deb3-4ee2-86cd-1f2145a5193e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;username-error-message&quot;)/span[@class=&quot;Text-sc-g5kv67-0 iDJBsn&quot;]</value>
      <webElementGuid>f3fcc8cc-4bdf-49f5-8726-8d7830231839</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='username-error-message']/span</value>
      <webElementGuid>231bfbe2-ea61-4e41-9240-5d463a7811ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email address'])[1]/following::span[1]</value>
      <webElementGuid>4edb937f-2e9d-477d-bdf8-e7caa850d8d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up to start listening'])[1]/following::span[1]</value>
      <webElementGuid>7eceb45f-569e-41ef-993b-4ce7583de702</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Did you mean'])[1]/preceding::span[1]</value>
      <webElementGuid>8ad126ee-6a4f-4f99-9290-e016cb0f6ac9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Invalid email address. Verify the spelling and try again.']/parent::*</value>
      <webElementGuid>25bbeace-d148-4d08-af3a-6a9e29566a46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>c466a034-b205-4f62-bd5b-ded260a023df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Invalid email address. Verify the spelling and try again.' or . = 'Invalid email address. Verify the spelling and try again.')]</value>
      <webElementGuid>ced48fd4-b244-4f06-ada5-3f51d8b3a398</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
