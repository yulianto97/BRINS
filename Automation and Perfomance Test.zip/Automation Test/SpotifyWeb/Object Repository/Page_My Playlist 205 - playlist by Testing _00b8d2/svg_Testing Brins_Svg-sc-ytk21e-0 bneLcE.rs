<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Testing Brins_Svg-sc-ytk21e-0 bneLcE</name>
   <tag></tag>
   <elementGuidId>54febde9-dcd8-4a56-b08a-3fc02929d529</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Testing Brins'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.IconWrapper__Wrapper-sc-16usrgb-0.hYdsxw > svg.Svg-sc-ytk21e-0.bneLcE</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>19320eff-1f3f-48be-8934-ceddbc8abea9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-encore-id</name>
      <type>Main</type>
      <value>icon</value>
      <webElementGuid>98d36fcb-3705-4cec-a62a-c336905c12de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>be21f483-3fef-48c3-9a48-a30a4fd6aa26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>18923650-19c3-4b84-9b71-01d425966b70</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>621eedac-e69a-49df-83e3-405aae41c480</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Svg-sc-ytk21e-0 bneLcE</value>
      <webElementGuid>34027910-2da9-4a2a-bc0e-dfb4d1fa6689</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/div[@class=&quot;Root&quot;]/div[@class=&quot;ZQftYELq0aOsg6tPbVbV&quot;]/div[@class=&quot;jEMA2gVoLgPQqAFrPhFw&quot;]/div[@class=&quot;main-view-container&quot;]/div[@class=&quot;main-view-container__scroll-node&quot;]/div[2]/div[@class=&quot;main-view-container__scroll-node-child&quot;]/main[@class=&quot;T0fKO6B7LQSCE_VaSM1P&quot;]/div[@class=&quot;GlueDropTarget GlueDropTarget--tracks GlueDropTarget--local-tracks GlueDropTarget--episodes GlueDropTarget--albums&quot;]/section[@class=&quot;dZ3U5sTGUTdanNamXe1z&quot;]/div[@class=&quot;rezqw3Q4OEPB1m4rmwfw&quot;]/div[2]/div[2]/div[@class=&quot;E4q8ogfdWtye7YgotBlN contentSpacing&quot;]/div[@class=&quot;eSg4ntPU2KQLfpLGXAww&quot;]/button[@class=&quot;Button-sc-1dqy6lx-0 hnwraf&quot;]/span[@class=&quot;IconWrapper__Wrapper-sc-16usrgb-0 hYdsxw&quot;]/svg[@class=&quot;Svg-sc-ytk21e-0 bneLcE&quot;]</value>
      <webElementGuid>8d9c1336-9371-44be-9d0c-d7156bb8c081</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Testing Brins'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>e0f5df86-b04e-4d9b-a2d9-e0d7563d8c3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Playlist #205'])[3]/following::*[name()='svg'][1]</value>
      <webElementGuid>d3753409-d25d-4a90-9476-79c69d01be97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='List'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>17af97da-a98c-4aec-b840-e20f50762a5c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
