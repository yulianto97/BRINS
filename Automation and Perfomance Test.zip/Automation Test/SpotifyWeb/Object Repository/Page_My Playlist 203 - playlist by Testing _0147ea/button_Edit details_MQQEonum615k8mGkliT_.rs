<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Edit details_MQQEonum615k8mGkliT_</name>
   <tag></tag>
   <elementGuidId>ef415e9f-0241-4243-952f-e5866d195506</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit details'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.MQQEonum615k8mGkliT_</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>ba87e54e-4904-4edd-ae4c-0e03fb1d185a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MQQEonum615k8mGkliT_</value>
      <webElementGuid>5d4378a6-975a-4de9-b854-5c28cf57242e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-focus-outline spotify__os--is-windows spotify__container--is-web&quot;]/body[@class=&quot;encore-dark-theme encore-layout-themes GenericModal__Body--open&quot;]/div[@class=&quot;ReactModalPortal&quot;]/div[@class=&quot;GenericModal__overlay&quot;]/div[@class=&quot;GenericModal&quot;]/div[@class=&quot;PiyAiXdQULEnWAHP0tu1&quot;]/div[@class=&quot;R2w_sH83CJU9Yhnu0xyt&quot;]/button[@class=&quot;MQQEonum615k8mGkliT_&quot;]</value>
      <webElementGuid>704bad60-faad-474f-bcae-e47b07077285</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit details'])[1]/following::button[1]</value>
      <webElementGuid>25c88cd6-9361-4ef5-a621-ba6715c87d41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Now playing: Mesin Waktu by Budi Doremi'])[1]/following::button[1]</value>
      <webElementGuid>85db36c7-214f-4786-b177-a6ea8fd1945e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Choose photo'])[2]/preceding::button[1]</value>
      <webElementGuid>41c5e026-e75b-4882-a5ec-aa246e8e8b47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit photo'])[1]/preceding::button[2]</value>
      <webElementGuid>a4482805-4ab0-4971-809f-f9f31e6042cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[22]/div/div/div/div/button</value>
      <webElementGuid>4e4ef2d7-76ef-46cf-82be-9ab734da6719</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
