<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_PlaylistTesting Brins_Svg-sc-ytk21e-0 dYnaPI</name>
   <tag></tag>
   <elementGuidId>fa1776e2-e5b9-4278-88a2-98456f70062e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Testing Brins Adit 20240328-121618'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.Button-sc-1dqy6lx-0.hidZeW.yclq4HDmRA_euiUYwB9O > span.IconWrapper__Wrapper-sc-16usrgb-0.hYdsxw > svg.Svg-sc-ytk21e-0.dYnaPI</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>e96c9132-f2f5-4c73-accb-263a6450f77c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-encore-id</name>
      <type>Main</type>
      <value>icon</value>
      <webElementGuid>c3ba0970-5b49-43c1-af86-f45766fffb61</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>cb1a86a0-f4db-4ff6-8b94-48ee38180a23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>06b08e70-7040-490c-a9aa-745a20e8fea6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 16 16</value>
      <webElementGuid>0e643cb3-f222-46df-9672-f6ddc694b69e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Svg-sc-ytk21e-0 dYnaPI</value>
      <webElementGuid>6a0467e7-4eaa-45a7-867f-4193aad38552</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Desktop_LeftSidebar_Id&quot;)/nav[@class=&quot;lYpiKR_qEjl1jGGyEvsA&quot;]/div[@class=&quot;lHJd4oSttKLxkxuoZ0Lr wM72343CksOCaL3bZvKK&quot;]/div[@class=&quot;hgJel0bLlS_1Uf0EIfSA&quot;]/div[@class=&quot;cZ3IJprhLYLVtLoxVtDe&quot;]/div[@class=&quot;Popover__StyledPopover-sc-1iog353-0 hUICWc encore-announcement-set C8nlESBb6d0huyAhMq2v&quot;]/button[@class=&quot;Button-sc-1dqy6lx-0 hidZeW yclq4HDmRA_euiUYwB9O&quot;]/span[@class=&quot;IconWrapper__Wrapper-sc-16usrgb-0 hYdsxw&quot;]/svg[@class=&quot;Svg-sc-ytk21e-0 dYnaPI&quot;]</value>
      <webElementGuid>a8509de6-36c5-425f-863b-9b2a705bd596</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Testing Brins Adit 20240328-121618'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>8a4d95f1-7665-4577-9280-98cb9ddbaf96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Resize main navigation'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>9419836c-60e4-4ce9-8d73-d98d9843144f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mesin Waktu'])[1]/preceding::*[name()='svg'][3]</value>
      <webElementGuid>ef536836-54f3-4ba5-bf4b-8aabf68787fe</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
